package framework.solution;

import framework.graph.Vertex;
import framework.problem.Problem;
import java.util.Comparator;
import java.util.PriorityQueue;
import java.util.Queue;

/* imports go here */

/**
 * This class represents an A* solver by extending the StateSpaceSolver
 * class.
 * @author Your name and section here
 */
public class AStarSolver extends StateSpaceSolver {
    
    /**
     * Creates an A* solver.
     * This constructor should set the queue to a priority queue (PQ)
     * and set the statistics header.
     * @param problem 
     */
    public AStarSolver(Problem problem) {
        super(problem, false);
        //Comparator<Vertex> comparator = null;
        setQueue((Queue<Vertex>)comparator);
        PriorityQueue<Vertex> queue = new PriorityQueue<Vertex>(10, comparator);
        /* you must provide */
    }
    
    /**
     * Adds a vertex to the PQ.
     * @param v the vertex to be added
     */
    @Override
    public void add(Vertex v) {
        /* you must provide */
    }
    
    /**
     * Creates a comparator object that compares vertices for ordering
     * in a PQ during A* search.
     * This should be used when creating the PQ.
     * @return the comparator object
     */
    public final Comparator<Vertex> getComparator() {
        
        return comparator;
        /* you must provide */
    }
    Comparator<Vertex> comparator;
}